<?php if ($primary_navigation): print $primary_navigation; endif; ?>
<?php if ($secondary_navigation): print $secondary_navigation; endif; ?>
