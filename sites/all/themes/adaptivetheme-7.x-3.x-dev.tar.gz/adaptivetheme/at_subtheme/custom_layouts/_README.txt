
  If you are not developing a page layout plugin you can safely delete this
  entire directory from your sub-theme.

  If you are developing a page layout plugin see the developer notes in
  AT Core /layouts/core/_README.txt, there are many code comments in the
  three_col_grail inc file also.

  You can enable the "naked" example layout plugin by uncommenting the
  info file entry in your subthemes info file. Look for:

  plugins[page_layout][layouts] = custom_layouts
