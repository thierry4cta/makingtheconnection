
# Non CSS Images

This directory is for images that at are not used in CSS. By default
only the touch icons are included here. In short, if your image is 
loaded using an img or link element the image should be stored here.
