<?php
/**
 * To use replace "adaptivetheme_subtheme" with your themeName and uncomment.
 */
/* -- Delete this line to enable.
function adaptivetheme_subtheme_form_system_theme_settings_alter(&$form, &$form_state)  {
  // Your knarly custom theme settings go here...
}
// */